import { motion } from "motion/react";
import { FolderGit2, ArrowUpRight, Monitor, Smartphone, Globe } from "lucide-react";

interface ProjectItem {
  title: string;
  category: string;
  description: string;
  tags: string[];
  links: { demo?: string; github?: string };
  icon: string;
  featured: boolean;
}

const PROJECTS_DATA: ProjectItem[] = [
  {
    title: "Aura Spatial",
    category: "Creative Development",
    description: "A highly immersive, interactive audio space with dynamic CSS grids and coordinate tracking, tuned for full iPad and mobile gesture inputs.",
    tags: ["React", "TypeScript", "GSAP", "TailwindCSS"],
    links: { demo: "#", github: "#" },
    icon: "🪐",
    featured: true
  },
  {
    title: "Krypton UI",
    category: "Design Systems",
    description: "A developer-first component framework focused entirely on fluid fluid-typography variables, extreme layout responsiveness, and dark-mode optimization.",
    tags: ["TypeScript", "TailwindCSS", "CSS Variables"],
    links: { demo: "#", github: "#" },
    icon: "💎",
    featured: true
  },
  {
    title: "Nova Engine",
    category: "Data Visualization",
    description: "Real-time astronomical mapping pipeline built to render and animate over stellar datasets smoothly. Features smooth custom gesture zooming for mobile.",
    tags: ["React", "D3.js", "Vite", "Motion"],
    links: { demo: "#", github: "#" },
    icon: "✨",
    featured: false
  },
  {
    title: "Pulse Feed",
    category: "Web Application",
    description: "Offline-first, responsive news reader displaying customized micro-layouts and elegant typography pairings. Built with local compression technologies.",
    tags: ["React", "LocalForage", "TailwindCSS"],
    links: { demo: "#", github: "#" },
    icon: "⚡",
    featured: false
  }
];

export default function Projects() {
  return (
    <section 
      id="projects" 
      className="py-24 px-6 md:py-32 bg-[#0d0e11] relative overflow-hidden"
    >
      {/* Decorative Blur Backgrounds */}
      <div className="absolute top-1/4 left-1/3 w-80 h-80 rounded-full bg-blue-500/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/3 w-80 h-80 rounded-full bg-emerald-500/5 blur-[120px] pointer-events-none" />

      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-4">
          <div>
            <span className="text-xs font-mono uppercase tracking-[0.25em] text-gray-400 flex items-center gap-2">
              <FolderGit2 className="w-3.5 h-3.5" /> SELECTED WORKS
            </span>
            <h2 className="text-4xl sm:text-5xl font-georama font-bold mt-2 text-white italic">
              Projects
            </h2>
          </div>
          <p className="text-xs font-mono text-gray-600 self-start md:self-end">
            /02 INTERACTIVE SHOWCASE
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8" id="projects-grid">
          {PROJECTS_DATA.map((project, idx) => (
            <motion.div
              key={idx}
              whileHover={{ y: -6 }}
              whileTap={{ scale: 0.99 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className={`p-6 sm:p-8 rounded-3xl border border-gray-900 bg-gray-950/40 hover:bg-gray-950/90 hover:border-gray-800 transition-all duration-300 flex flex-col justify-between relative group ${
                project.featured ? "md:col-span-2 md:grid md:grid-cols-5 md:gap-8 md:items-center" : ""
              }`}
              id={`project-card-${idx}`}
            >
              {/* Project Icon */}
              <div className={`hidden sm:flex items-center justify-center text-4xl w-14 h-14 rounded-2xl bg-gray-900/60 border border-gray-800 group-hover:border-gray-700/80 mb-6 sm:mb-0 ${
                project.featured ? "md:col-span-1" : "mb-6"
              }`}>
                {project.icon}
              </div>

              {/* Core Content */}
              <div className={project.featured ? "md:col-span-4 space-y-4" : "space-y-4 h-full flex flex-col justify-between"}>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono uppercase tracking-wider text-gray-500">
                      {project.category}
                    </span>
                    <div className="flex items-center gap-1.5 text-xs text-gray-600">
                      <Monitor className="w-3 h-3" />
                      <Smartphone className="w-3 h-3" />
                    </div>
                  </div>

                  <h3 className="text-2xl font-georama font-semibold text-white flex items-center gap-2 group-hover:text-white transition-colors">
                    {project.title}
                    <ArrowUpRight className="w-4 h-4 text-gray-600 group-hover:text-white group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all duration-300" />
                  </h3>

                  <p className="text-sm sm:text-base text-gray-400 font-light mt-3 leading-relaxed">
                    {project.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-gray-900/60 mt-auto">
                  {/* Technology Tags Wrap */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {project.tags.map((tag, tagIdx) => (
                      <span 
                        key={tagIdx} 
                        className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-gray-900/80 text-gray-400 border border-gray-800/60 hover:border-gray-700 transition-colors"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Actions Links */}
                  <div className="flex items-center gap-4 text-xs font-mono mt-3">
                    <a 
                      href={project.links.demo} 
                      className="text-white hover:underline flex items-center gap-1 transition-colors cursor-pointer"
                      onClick={(e) => e.preventDefault()}
                    >
                      <Globe className="w-3.5 h-3.5" /> LIVE DEMO
                    </a>
                    <a 
                      href={project.links.github} 
                      className="text-gray-500 hover:text-white hover:underline flex items-center gap-1 transition-colors cursor-pointer"
                      onClick={(e) => e.preventDefault()}
                    >
                      SOURCE CODE
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
